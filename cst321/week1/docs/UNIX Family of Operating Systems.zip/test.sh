/* Linux test.sh */
#include<stdio.h>

date
users
whoami
ls
echo $PATH

